# Pra fora

Este projeto permite um usuário cadastrar uma mensagem que é vista no mural principal da página
