<?php
//rotas da aplicação
//a variável $uri já contém os dados da rota solicitada

switch ($uri) {
    
    case '/':
        require 'index.html';
        break;
    
    case '/c':
        require './contato.html';
        break;
    case '/f':
        require './filmes.html';
        break;
    case '/consulta':
        require './MessageController.php';
        break;
         
    default:
        die('Essa rota não é valida');
        break;
}
